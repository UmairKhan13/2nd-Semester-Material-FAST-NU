// QUESTION #3
// Create a RestaurantMeal class that holds the name and price of a food item
// served by a restaurant. Its constructor requires arguments for each field. Create
// a HotelService class that holds the name of the service, the service fee, and the
// room number to which the service was supplied. Its constructor also requires
// arguments for each field. Create a RoomServiceMeal class that inherits from
// both RestaurantMeal and HotelService. Whenever you create a
// RoomServiceMeal object, the constructor assigns the string �room service� to the
// name of the service field, and $4.00 is assigned to the service fee inherited from
// HotelService. Include a RoomServiceMeal function that displays all of the fields
// in a RoomServiceMeal by calling display functions from the two parent classes.
// Additionally, the display function should display the total of the meals plus the
// room service fee. In a main() function, instantiate a RoomServiceMeal object that
// inherits from both classes. For example, a �steak dinner� costing $19.99 is a �room
// service� provided to room 1202 for a $4.00 fee.

#include<iostream>
using namespace std;

class RestaurantMeal
{
    protected:
    string name;
    float price_of_food;
    
    public:
    RestaurantMeal(string name,float price_of_food)
    {
        this->name=name;
        this->price_of_food=price_of_food;
        
    }
    
    void displays()
    {
        cout << "a \"" << name << "\" Costing $" << price_of_food << " is a "  ;
    }  
    
};

class HotelService
{
   protected:
   string service_name;
   float service_fee;
   int room_num;
   
   public:
     
     HotelService(string service_name,float service_fee,int room_num)
     {
         this->room_num = room_num;
         this->service_fee = service_fee;
         this->room_num = room_num;
     }
     
    void displays()
    {
        cout << service_name << " Provided to Room " << room_num << " for a " << service_fee <<"$ fee" ;
    }
};

class RoomServiceMeal : public RestaurantMeal, public HotelService  
{
  public:
    RoomServiceMeal(string name,float fees):HotelService(name,fees,1202),RestaurantMeal("Steak Dinner",19.99)
    {
        service_name = name;
        service_fee = fees;
    }
    
    void displays()
    {
        RestaurantMeal::displays();
        HotelService::displays();
        
        float total;
        total = service_fee + price_of_food;
        cout << endl << "TOTAL OF MEAL AND ROOM SERVICE FEE = " << total;
    }
};

int main()
{
    RoomServiceMeal a("Room Service",4);
    a.displays();      
}

