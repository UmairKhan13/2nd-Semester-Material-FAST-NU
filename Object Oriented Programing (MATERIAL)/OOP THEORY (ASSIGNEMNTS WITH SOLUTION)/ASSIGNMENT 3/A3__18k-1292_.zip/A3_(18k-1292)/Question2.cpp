#include<iostream>
#include<string>
#include<iomanip>
using namespace std;

class Theatre{
	private:
		string playname;
		int adprice,chprice;
		int adSold,chSold,donate;   //adprice=Adult Ticket Price chprice=Child TicketPrice adSold=Adult ticket sold chSold=Child ticket sold 
		public:
			Theatre(string a,int b,int c,int d,int e,int f):
			playname(a),adprice(b),chprice(c),adSold(d),chSold(e),donate(f)
			{
				
			}
			
			void display()
			
			{
			    double total;
				total=adSold*adprice+chSold*chprice; 
				cout<<setfill('.')<<setw(40)<<left<<"\nMovie Name : "<<setw(10)<<right<<playname<<endl;
				cout<<left<<setw(40)<<"Number of Tickets sold : "<<setw(10)<<right<<adSold+chSold<<endl;
				cout<<left<<setw(40)<<"Gross Amount : "<<setw(6)<<right<<"$"<<total<<endl;
				cout<<left<<setw(40)<<"Percentage of Gross Amount Donated : "<<setw(9)<<right<<donate<<"% "<<endl;
				cout<<left<<setw(40)<<"Amount Donated : "<<setw(7)<<right<<"$"<<total*donate/100<<endl;
				cout<<left<<setw(40)<<"Net Sale : "<<setw(6)<<right<<"$"<<total-total*donate/100<<setw(10)<<endl;
				
			}
			
};

int main()
{   char play[100];
    int atick,ctick,asold,csold,donate;
	cout<<"Enter Play Name :";
    cin.getline(play,sizeof(play));
	cout<<"Enter Price of Adults ticket :";
	cin>>atick;
	cout<<"Enter Price of Child ticket :";
	cin>>ctick;
	cout<<"Enter Number of Adult tickets sold :";
	cin>>asold;
	cout<<"Enter Number of Child tickets sold :";
	cin>>csold;
	cout<<"Enter Percent of be donated :";
	cin>>donate;
	Theatre t1(play,atick,ctick,asold,csold,donate);
	t1.display();

}
