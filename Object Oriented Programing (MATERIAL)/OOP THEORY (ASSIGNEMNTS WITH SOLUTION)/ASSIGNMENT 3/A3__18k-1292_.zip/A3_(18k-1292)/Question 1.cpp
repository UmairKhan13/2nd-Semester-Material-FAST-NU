#include<iostream>
#include<fstream>
using namespace std;
class parts{
string menuItem[10];
double menuPrice[10];
int quantity[10];
double tPrice =0;
public:
void setData(){
menuItem[0]="Hammer";
menuItem[1]="Screw Driver";
menuItem[2]="Electric Sander";
menuItem[3]="Jig Saw";
menuItem[4]="Power Saw";
menuItem[5]="Lawn Mower";
menuItem[6]="Sledge Hammer";
menuItem[7]="Wrench";
menuItem[8]="Mallet";
menuItem[9]="Axe";
menuPrice[0]= 5.45;
menuPrice[1]= 3.20;
menuPrice[2]= 7.00;
menuPrice[3]= 6.99;
menuPrice[4]= 12.9;
menuPrice[5]= 13.00;
menuPrice[6]= 2.00;
menuPrice[7]= 8.45;
menuPrice[8]= 12.00;
menuPrice[9]= 13.00;
menuPrice[9]= 13.00;
for(int i=0;i<10;i++){
quantity[i]=0;
}
}
void showMenu(double budget){
    cout<<"\n\n\t\t----- Welcome to Spare Parts Shop-----"<<endl;
for(int i =0;i<10;i++){cout<<i+1<<")"<<menuItem[i]<<"$"<<menuPrice[i]<<endl;}
int ch=1;
while(ch != 0){
cout<<"Enter the item number you want to but or press 0 to generate your bill: ";
cin>>ch;
if(ch> 0){
if(tPrice + menuPrice[ch-1] <= budget){
quantity[ch-1]++;
tPrice += menuPrice[ch-1];
}
else{
cout<<"Balance is Not Enough"<<endl;
}
}
}
}
void printBill(){
ofstream out;
out.open("bill.txt",ios::out);
for(int i =0;i<10;i++){
if(quantity[i]>0){
out<<menuItem[i]<<" X "<<quantity[i]<<"\n";
}
}
if(tPrice > 0){
out<<"Total bill is of :"<<tPrice;
}
out.close();
cout<<"Total bill is of :"<<tPrice;
}
};

int main(){
parts p1;
p1.setData();
p1.showMenu(500);
p1.printBill();
return 0;
}
