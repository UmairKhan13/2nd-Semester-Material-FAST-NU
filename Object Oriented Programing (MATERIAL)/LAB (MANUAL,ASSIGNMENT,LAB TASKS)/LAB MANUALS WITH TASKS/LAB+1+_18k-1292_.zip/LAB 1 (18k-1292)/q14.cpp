#include <iostream>
float findf(float x, float y, float n);
using namespace std;
int main()
{
	float n,x,y,F;
	cout<<"enter value of x: ";
	cin>>x;
	cout<<"\nenter value of y: ";
	cin>>y;
	cout<<"\nenter value of n either negative or positive: ";
	cin>>n;
	F=findf(x,y,n);
	cout<<"\nvalue of F is: "<<F;
	return 0;
}
float findf(float x, float y, float n)
{
	if(n>0)
	{
		return x+y;
	}
	else
	{
		return x-y;
	}
}
