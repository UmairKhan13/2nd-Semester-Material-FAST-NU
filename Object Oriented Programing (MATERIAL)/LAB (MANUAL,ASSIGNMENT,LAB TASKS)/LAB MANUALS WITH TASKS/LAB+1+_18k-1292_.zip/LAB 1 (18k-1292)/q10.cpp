#include <iostream>
using namespace std;
int main()
{
	int num,i=0,res=0;
	cout<<"enter a number: ";
	cin>>num;
	
	for(i=1;i<=num;i*=10)
	{
		if(num/i%10==0)
		{
			res+=i;
			continue;
		}
		res+=((num/i%10)+1)*i;
	}
	cout<<"\nthe number "<<num<<" after adding 1 in each digit is:"<<res;

}
