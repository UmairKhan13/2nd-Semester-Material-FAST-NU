#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout<<"enter an even number greater than 50: ";
	cin>>num1;
	cout<<" "<<num1<<endl;
	for(int i=0;i<5;i++)
	{
		num1/=2;
		cout<<" "<<num1<<endl;
		num1+=2;
		cout<<" "<<num1<<endl;
	}
}
