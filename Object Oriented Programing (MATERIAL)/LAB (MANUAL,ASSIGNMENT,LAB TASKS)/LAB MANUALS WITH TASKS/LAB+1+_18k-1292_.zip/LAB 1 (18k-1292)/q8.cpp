#include<iostream>
using namespace std;
int main()
{
	int guest,chair;
	int prob=1,a,b;
	cout<<"\t\t***chairs should be lesser than guests***\n\n";
	cout<<"enter number of guests: ";
	cin>>guest;
	cout<<"\nenter number of chairs: ";
	cin>>chair;
	a=chair;
	b=guest;
	if(chair<guest)
	{
		for(int i=0;i<chair;i++)
		{
			prob=prob*guest;
			guest--;
		}
	}
	else
	{
		cout<<"\n";
		main();
	}
	cout<<"\ntotal probability to arrange "<<b<<" guests into "<<a<<" chairs is "<<prob;
	return 0;
}
