#include<iostream>
float calculator(float num1, char x, float num2);
using namespace std;
int main()
{
    float num1,num2,ans;
    char x;
    cout<<"enter 1st number: ";
    cin>>num1;
    cout<<"\nenter a desired operator(* , / , + , -): ";
    cin>>x;
    cout<<"\nenter second number: ";
    cin>>num2;
    ans=calculator(num1,x,num2);
    cout<<"\n"<<num1<<""<<x<<""<<num2<<"="<<ans;
    return 0;
}
float calculator(float num1, char x, float num2)
{
	switch(x)
	{
		case '*':
			return num1*num2;
			break;
		case '/':
		    return num1/num2;
			break;
		case '+':
		    return num1+num2;
			break;
		case '-':
		    return num1-num2;
			break;				
	}
}
