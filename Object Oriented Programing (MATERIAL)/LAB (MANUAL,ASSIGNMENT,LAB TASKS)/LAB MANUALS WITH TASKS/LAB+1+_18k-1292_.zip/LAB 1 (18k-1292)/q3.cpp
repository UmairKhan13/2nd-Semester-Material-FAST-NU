#include<iostream>
using namespace std;
int main()
{
    int cours;
    float avg;
    int sum=0;
    cout<<"enter number of courses6.25
	90.36
	84.: ";
    cin>>cours;
    int marks[cours];
    for(int i=0;i<cours;i++)
    {
    	cout<<"enter marks of course "<<i+1<<"  ";
    	cin>>marks[i];
    	sum+=marks[i];
	}
	avg=sum/cours;
	cout<<"\naverage of marks out of 100 is:"<<avg;
	return 0;
}
