#include<iostream>
#include<iomanip>
using namespace std;
class Distance{
	
	private:
		int dis;
		float feet;
		int inches;
	public:
		Distance(){
			feet=0;
			dis=0;	
			inches=0;
		}
		void distance(){
			cout<<"enter distance in meters : ";
			cin>>dis;
		}
		int distinmeter(){
			return dis;
		}
		int distinfeet(){
			feet = ( ( dis ) * ( 3.2808 ) );							 	
			return feet;	
		}
		int distininch(){
			feet = ( ( dis ) * ( 3.2808 ) * ( 10 ) );
			inches = (  (int) ( feet ) ) % 10;
			return inches;
		}
		void display(){
			cout<<endl<<"Distance int meters : "<<distinmeter()<<" meters ";
			cout<<endl<<"Distance in feet : "<<distinfeet()<<" feet "<<distininch()<<" inches "<<endl;
		}
		~Distance(){
			cout<<endl<<"object destroyed";
		}
};
int main(){
	
	Distance d1;
	d1.distance();
	d1.display();
}
