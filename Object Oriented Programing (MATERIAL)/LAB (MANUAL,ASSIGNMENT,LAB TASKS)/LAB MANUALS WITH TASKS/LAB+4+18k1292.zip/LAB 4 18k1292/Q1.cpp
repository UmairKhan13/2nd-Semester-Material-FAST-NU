#include<iostream>
#include<string.h>
using namespace std;
class Shoplist{
	private:
		int code_no, qty; 
		double price, total;
	public:
		double net;
		Shoplist(){
			total=0.0;			
		}
		void list(int code_no,double price,int qty){
			this->code_no= code_no; 
			this->price = price; 
			this->qty = qty;
		}
		int get_code(){
			return code_no;
		}
	    int add(int ad){
			this->qty=qty+ad;
		}
		int del(int delt){
			this->qty=qty-delt;
		}
		void Details(){
			net=(qty*price);
			cout<<endl<<" "<<code_no<<"\t\t  "<<qty<<"  \t\t\t  "<<price<<" \t\t\t\t "<<net<<" \t\t\t "<<net;
		}
		~Shoplist(){
			cout<<endl<<"Object Destroyed!";
		}
};
int main(){
	double sum=0,price;
	int code_no,qty,size,codee,x,y,z;                  // x,z are operators for switch case
	cout<<"Enter total items to create : ";
	cin>>size;
	Shoplist s1[size];
	for(int i=0;i<size;i++){
		cout<<"Item # "<<i+1<<endl;
		cout<<"Enter code : ";
		cin>>code_no;
		cout<<"Enter qty : ";
		cin>>qty;
		cout<<"Enter price : ";
		cin>>price;
		s1[i].list(code_no, price, qty);
	}
	cout<<"press 1 to alter\npress any key to exit\n";
	cin>>z;
	switch(z){
			case 1:{
				cout<<"enter number of items u want to alter : ";
				cin>>y;
				for(int i=0;i<y;i++){
					switch(z){
						case 1:{
							cout<<"Enter code to search : ";
							cin>>codee;
							for(int i=0;i<size;i++){
								if(s1[i].get_code()==codee){
									cout<<"press 1 to add\npress 2 to del\npress any key to exit\n";
									cin>>x;
									switch(x){
										case 1:{
											int num;
											cout<<"enter number of qty  u want to add : ";
											cin>>num;
											s1[i].add(num);		
											break;
										}
										case 2:{
											int num;
											cout<<"enter number of qty  u want to del : ";
											cin>>num;
											s1[i].del(num);		
											break;
										}
										default:
											cout<<endl;
									}
									break;
								}
							}
							break;
						}
						default:
							cout<<endl;
					}
				}
				break;
			}
		default:
			cout<<endl;
	}
	cout<<"____________________________________________________________________________________________________________________"<<endl;
	cout<<" Code # \t Quantity \t\t Price \t\t\t   Total Net \t\t Total Amount"<<endl;
	cout<<"____________________________________________________________________________________________________________________"<<endl;
	for(int i=0;i<size;i++){
		s1[i].Details();
	}
	for(int i=0; i<size; i++){
		sum = sum + s1[i].net;  
	}
	cout<<endl<<"____________________________________________________________________________________________________________________"<<endl;	
	cout<<endl<<"\t\t\t\t\t\t\t\t\t\t\t\t "<<sum;
	cout<<endl;
}
