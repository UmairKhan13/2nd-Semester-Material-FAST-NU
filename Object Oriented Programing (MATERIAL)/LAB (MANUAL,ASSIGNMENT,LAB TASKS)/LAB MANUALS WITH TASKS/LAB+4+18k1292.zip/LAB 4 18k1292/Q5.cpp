#include<iostream>
using namespace std;
class Student{
	private:
		string 	name, roll_no, semester;
		char section;
	public:
		Student(string 	name, string roll_no, string semester, char section){
			this->name=name;
			this->roll_no=roll_no;
			this->semester=semester;
			this->section=section;
		}
		void display(){
			cout<<endl<<"Name : "<<name;
			cout<<endl<<"Roll # "<<roll_no;
			cout<<endl<<"Semester :"<<semester;
			cout<<endl<<"Section : "<<section;
		}
};
int main(){
	
	string 	name, roll_no, semester;
	char section;
	
	cout<<"Enter Name : ";
	getline(cin,name);
	cout<<"Enter Roll # ";
	getline(cin,roll_no);
	cout<<"Enter Semester : ";
	getline(cin,semester);
	cout<<"Enter Section : ";
	cin>>section;
	
	Student stu(name, roll_no, semester, section);
	stu.display();
}
