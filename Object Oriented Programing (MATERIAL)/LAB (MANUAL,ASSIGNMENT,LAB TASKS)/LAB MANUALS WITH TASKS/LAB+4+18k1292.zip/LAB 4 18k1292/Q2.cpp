#include<iostream>
using namespace std;
class Phone
{
	private:
		string ph_no, areacode, excode, consumerno;
	public:
		
		Phone(string ph)
		{
			ph_no=ph;	
			int n = ph_no.length();	
			for(int i=0;i<n;i++){
					if(i>=0 && i<3){
					areacode+=ph_no[i];
				}
				else if(i>=3 && i<7){
					excode+=ph_no[i];
				}
				else if(i>=7 && i<11){
					consumerno+=ph_no[i];
				} 
			}
		}
		void display()
		{	
			cout<<"Your Area Code : "<<areacode<<endl;
			cout<<"Your Exchange Code : "<<excode<<endl;
			cout<<"Your Consumer Number : "<<consumerno<<endl;
		}
};
int main()
{
	string ph_no;
	cout<<"Please Enter Your Number : ";
	getline(cin,ph_no);
	Phone p1(ph_no);
	p1.display();
}
