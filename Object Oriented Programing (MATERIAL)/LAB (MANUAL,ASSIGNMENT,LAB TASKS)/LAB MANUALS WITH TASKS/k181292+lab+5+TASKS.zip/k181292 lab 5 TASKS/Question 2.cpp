#include<iostream>
using namespace std;
class RentCalculator{
	private:
		const float RentPerDay;
		float CustomerRent;
		 const string Name;
		int NumberOfDays;
	public:
		RentCalculator(string name, int numberOfDays):Name(name),RentPerDay(1000.85){
			this->NumberOfDays=numberOfDays;
		} 
		string name()const{
			return Name;
		}
		int days(){
			return NumberOfDays; 
		}
		float RentWithBonus(){
			NumberOfDays=(NumberOfDays-1);
			CustomerRent = (NumberOfDays)*RentPerDay;
			return CustomerRent;	
		}
		float RentWithoutBonus(){
			CustomerRent = NumberOfDays*RentPerDay;
			return CustomerRent;
		}
		const void DisplayRent(){
			cout<<"Customer Name : "<<name()<<endl;
			cout<<"Days : "<<days()<<endl;
			if(NumberOfDays>7){
				cout<<"Rent : "<<RentWithBonus()<<endl;
			}
			else{	
				cout<<"Rent : "<<RentWithoutBonus()<<endl;
			}
		}
};
int main(){	
	int numofdays;
	string Name;
	cout<<"Enter Customer Name : ";
	getline(cin,Name);
	cout<<"Enter Number Of Days : ";
	cin>>numofdays;
	RentCalculator r1(Name,numofdays);
	fflush(stdin);
	cout<<"Enter Customer Name : ";
	getline(cin,Name);
	cout<<"Enter Number Of Days : ";
	cin>>numofdays;
	RentCalculator r2(Name,numofdays);
	r1.DisplayRent();
	r2.DisplayRent();	
}
