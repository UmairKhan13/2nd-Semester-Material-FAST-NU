#include<iostream>
#include<string.h>
using namespace std;
void reverse_array(char *a)
{
	int temp;
	int c=strlen(a);
	for (int i = 0; i < c/2; ++i) 
	{
    	temp = a[c-i-1];
    	a[c-i-1] = a[i];
    	a[i] = temp;
	}
}
int main()
{
	string ar;
	cout<<"enter any element : ";
	getline(cin,ar);
	
	char *a;
	a=&ar[0];
	int c=strlen(a);
	
	reverse_array(a);
	for(int i=0;i<c;i++)
	{
		cout<<a[i]<<" ";
	}
}
