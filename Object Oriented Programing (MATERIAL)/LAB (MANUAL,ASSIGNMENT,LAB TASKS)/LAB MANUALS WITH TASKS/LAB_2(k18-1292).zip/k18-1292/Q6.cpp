#include <iostream>
using namespace std;
int *time_converter(int time_in_seconds)
{
	int *time;
	time=new int [3];
	time[0] = time_in_seconds/3600;
	time[1] = (time_in_seconds%3600)/60;
	time[2] = (time_in_seconds%3600)%60;
	return time;
}
int main()
{
	int time_in_seconds;
	
	cout << "Enter the time in seconds: " ;
	cin >> time_in_seconds;	
	int *ans;
	ans=new int [3];
	ans=time_converter(time_in_seconds);
	cout<<ans[0]<<" hour "<<ans[1]<<" minutes "<<ans[2]<<" seconds";
	return 0;
}
