#include<iostream>
#include<cstring>
using namespace std;
int reverse(char num[100])
{	
	static int c=strlen(num);
	if(c>=0)
	{
		cout<<num[c];
		c--;
		return reverse(num);
	}
	else 
	return 0;
}
int main()
{
	char number[100];
	cout<<"enter a positive integer number : ";
	cin>>number;
	reverse(number);
}
