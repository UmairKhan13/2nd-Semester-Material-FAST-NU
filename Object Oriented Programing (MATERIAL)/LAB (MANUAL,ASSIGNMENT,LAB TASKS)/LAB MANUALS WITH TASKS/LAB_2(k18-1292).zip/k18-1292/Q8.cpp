#include<iostream>
using namespace std;
int  countdigits(long long int n)
{
	static int count =0;
	if(n>0)
	{
		count++;
		return countdigits(n/10);
	}
	else 
		return count;
}
int main()
{
	long long int n;
	cout<<"Input : ";
	cin>>n;
	int ans=countdigits(n);
	cout<<"Output : "<<ans << " Digits";
}
