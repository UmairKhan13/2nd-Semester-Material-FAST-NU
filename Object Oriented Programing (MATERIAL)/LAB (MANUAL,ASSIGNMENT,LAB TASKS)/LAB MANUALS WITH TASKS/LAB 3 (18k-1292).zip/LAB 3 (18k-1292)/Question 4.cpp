#include<iostream>
#include<string.h>
using namespace std;
class Employee
{
	private:
		char *first_name;
		string last_name;
		int monthly_salary;
	public:
		void setdata(char *empname, string emplnam, int sal)
		{
			first_name= new char[100];
			first_name=empname;
			last_name=emplnam;
			monthly_salary=sal;
			display();
		}
		char* getFname()
		{
			return first_name;
		}
		string getLname()
		{
			return last_name;
		}
		int getsal()
		{
			if(monthly_salary<0)
			{
				monthly_salary=0;
				return monthly_salary;
			}
			else
			{
				return monthly_salary;
			}
		}
		int yearlysalary()
		{
			return ( ( getsal() ) *12 );
		}
		int increment()
		{
			return( ( ( yearlysalary() * 10 ) /100 ) + ( yearlysalary () ) );
		}
		void display()
		{
			if(yearlysalary())
			{	
				cout<<endl;		
				cout<<endl<<"First name : "<<getFname();
				cout<<endl<<"Last name : "<<getLname();
				cout<<endl<<"Monthly Salary : "<<getsal();
				cout<<endl<<"Yearly Salary : "<<yearlysalary();
				cout<<endl<<"Yearly Salary with Increment : "<<increment();
				cout<<endl;
				cout<<endl;
			}
			else
			{
				cout<<endl<<"First name : "<<getFname();
				cout<<endl<<"Last name : "<<getLname();
				cout<<endl<<"Monthly Salary : "<<getsal();
				cout<<endl<<"Yearly Salary : "<<yearlysalary();	
				cout<<endl<<"Yearly Salary with Increment : "<<increment();
				cout<<endl;
				cout<<endl;
			}
		}
};
int main()
{
	Employee employee1,employee2;
	char *f_nam;
	f_nam = new char[100];
	string l_nam;
	long unsigned int sal;
	
	cout<<"First Employee : "<<endl;
	cout<<"enter first name :";
	cin>>f_nam;
	fflush(stdin);
	cout<<"enter last name : ";
	getline(cin,l_nam);
	cout<<"enter monthly salary : ";
	cin>>sal;
	employee1.setdata(f_nam,l_nam,sal);
	
	cout<<"second Employee : "<<endl;
	cout<<"enter first name :";
	cin>>f_nam;
	fflush(stdin);
	cout<<"enter last name : ";
	getline(cin,l_nam);
	cout<<"enter monthly salary : ";
	cin>>sal;	
	employee2.setdata(f_nam,l_nam,sal);
}
