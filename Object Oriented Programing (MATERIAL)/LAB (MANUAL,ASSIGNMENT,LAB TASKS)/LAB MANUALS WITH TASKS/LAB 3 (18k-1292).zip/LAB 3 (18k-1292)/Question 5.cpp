#include<iostream>
#include<string.h>
using namespace std;
class Invoice
{
	private:
		string part_no,description;
		int quantity;
		float price_per_item;
	public:
		void setinvoice(string pt_no, string desc, int quant, float ppt)
		{
			part_no=pt_no;
			description=desc;
			quantity=quant;
			price_per_item=ppt;
		}
		string getpt_no()
		{
			return part_no;
		}
		string getdesc()
		{
			return description;
		}
		int getquant()
		{
			return quantity;
		}
		float getppt()
		{
			return 	price_per_item;	
		}
		double getInvoiceAmount()
		{
			if( quantity < 0 )
			{
				quantity=0;
			}
			if( price_per_item < 0.0 )
			{
				price_per_item=0;
			}
			return ((quantity)*(price_per_item));	
		}
		void displayinvoice()
		{
			cout<<endl<<"Part number : "<<getpt_no();
			cout<<endl<<"Description : "<<getdesc();
			cout<<endl<<"Quantity : "<<quantity;
			cout<<endl<<"Price per item : "<<price_per_item;
			cout<<endl<<"Invoice Amount : "<<getInvoiceAmount();
			cout<<endl;
			cout<<endl;
		}
};
int main()
{
	string part,desc;
	int qty;
	float ppit;
	cout<<"enter part number : ";
	getline(cin,part);
	cout<<"enter description : ";
	getline(cin,desc);
	cout<<"enter quantity : ";
	cin>>qty;
	cout<<"enter price per item : ";
	cin>>ppit;
	Invoice data;
	data.setinvoice(part,desc,qty,ppit);
	data.getInvoiceAmount();
	data.displayinvoice();
}
