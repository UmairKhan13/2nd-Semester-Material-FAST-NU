#include<iostream>
#include<conio.h>
using namespace std;

template <typename T>
class myclass{
	public:
		T x;
	int y;
		T sum(T *a , int n)
		{
			T Sum;
			for (int i=0; i<n; i++)
			{
				Sum = Sum + a[i];
			}
			cout << Sum << endl;
		}	
};
int main()
{
	int arr[5] = {1,2,3,4,5};
	myclass <int> Add;
	Add.sum(arr , 5);
	float arr1[] = {0.1,0.2,0.3,0.4,0.5};
	myclass <float> Add1;
	Add1.sum(arr1,5);
}

