#include<iostream>

using namespace std;

template<class T1, class T2, class T3>
class Inventory
{
	private:
		T1 item_code, description;
		T2 rate_per_unit;
		T3 total_units;
	public:
		Inventory()
		{
			
		}
		
		Inventory(T1 pi, T1 pd, T2 rpu, T3 tu)
		{
			item_code = pi;
			description = pd;
			rate_per_unit = rpu;
			total_units = tu;
		}
		
		T1 get_item_code()
		{
			return item_code;
		}
		
		T1 get_description()
		{
			return description;
		}
		
		T2 get_rate_per_unit()
		{
			return rate_per_unit;
		}
		
		T3 get_total_units()
		{
			return total_units;
		}
		
		void set_item_code(T1 code)
		{
			item_code = code;
		}
		
		void set_description(T1 pname)
		{
			description = pname;
		}
		
		void set_rate_per_unit(T2 rpu)
		{
			rate_per_unit = rpu;
		}
		
		void set_total_units(T3 tu)
		{
			total_units = tu;
		}
		
		void display()
		{
			cout << "ITEM CODE: " << get_item_code() << endl;
			cout << "DESCRIPTION: " << get_description() << endl;
			cout << "RATE PER UNIT: " << get_rate_per_unit() << endl;
			cout << "TOTAL UNITS: " << get_total_units() << endl;
		}
};
template<class T>
void display(T code, Inventory<string,float,int>array[])
{
	int flag=0;
	for (int i=0;i<5;i++)
	{
		if (array[i].get_item_code() == code)
		{
			array[i].display();
			
			flag = 1;
			break;
		}
	}
	if (!flag) cout << "NOT FOUND\n";
}


template <class T, class T1, class T2>
void edit_stock(T code, Inventory<string,float,int>array[])
{
	bool found = false;
	for (int i=0;i<5;i++)
	{
		if (array[i].get_item_code() == code)
		{
			cout << "Enter the new rate of unit: ";
			T1 rpu;
			cin >> rpu;
			array[i].set_rate_per_unit(rpu);
			cout << "Enter the new total unit stock: ";
			T2 tu;
			cin >> tu;
			array[i].set_total_units(tu);
			
			cout << "RECORD UPDATED\n";
			found = true;
		}
	}
	if (!found) cout << "NOT FOUND\n";
}

void display_detail(Inventory<string,float,int>array[])
{
	for (int i=0;i<5;i++)
	{
		array[i].display();
		cout << endl;
	}
}
 main()
{
	Inventory <string,float,int>obj_array[5] = { {"7899","sidhant",1500.0,3},{"3222","makhija",150.0,8},{"2221","ronaldo",749.99,4},
								{"5231","hello world ",1099.99,3}, {"42223","sid",999.99,3} };
	string code;	
	while (1)
	{
		cout << "\nplease Enter \n1. Edit stock.\n2. Display Detail of object/item.\n3. Display All.\n4. Exit\n";
		int interface;
		cin >> interface;
		if (interface==1)
		{
			cout << "Enter the item code for the item you want to edit stock of: ";
			cin >> code;
			
			edit_stock<string,float,int>(code, obj_array);
			
		}
		else if (interface==2)
		{
			cout << "Enter the item code for the item you want to display. ";
			cin >> code;
			
			display(code,obj_array);
		}
		else if (interface==3)
		{
			display_detail(obj_array);
		}
		else
		{
			break;
		}
	}
}
