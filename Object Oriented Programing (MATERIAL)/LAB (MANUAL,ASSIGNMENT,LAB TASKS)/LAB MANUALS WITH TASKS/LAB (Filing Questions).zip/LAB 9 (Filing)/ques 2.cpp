#include<conio.h>
#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	
	ifstream fs;
	ofstream ft;
	char stringg[100],ch[100];
	ft.open("nfile.txt");
	if(!fs)
	{
		cout<<"Error in opening source file..!!";
		getch();
		exit(1);
	}
	
	cout<<"enter the string to copy in second file: ";
	cin.getline(stringg,100);
	ft<<stringg<<endl;
	ft.close();
	
	fs.open("nfile.txt");
	ft.open("cfile.txt");
	if(!ft)
	{
		cout<<"Error in opening target file..!!";
		fs.close();
	    exit(2);
	}
	
		fs.getline(ch,100);
		ft<<ch;
	
	cout<<"File copied successfully..!!";
	fs.close();
	ft.close();
	
    char stringg_new[100];
	fs.open("cfile.txt");
	cout<<"\nreading from the file\n "<<endl;
	fs.getline(stringg_new,100);
	cout << stringg_new;
	fs.close();
}
