#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
	char stringg[1000];
	int i=0;
	ofstream STRR;
	STRR.open("1file.txt");
	cout<<"writting to the file\n";
	cout<<"enter the string : ";
	cin.getline(stringg,100);
	int len=strlen(stringg);
	STRR<<stringg<<endl;
	STRR.close();
	ifstream infile;
	infile.open("afile.date");
	cout<<"reading from the file "<<endl;
	infile>>len;
	cout<<"length of the string is "<<len<<endl;
	infile.close();
	infile.open("afile.date");
	cout<<"reading from the file "<<endl;
	while(i<len)
	{
		infile>>stringg[i];
		cout<<stringg[i];
		i++;
	}
	infile.close();
	return 0;
}
